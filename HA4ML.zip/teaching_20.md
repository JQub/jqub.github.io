---
date: 2020-02-10 17:00:00
title: Weiwen Jiang
categories: teaching
type: index
---

** George Mason University **
* ECE 618: Hardware Accelerators for Machine Learning [[Home Page]](/2022/01/01/HA4ML) <div style="float:right">Spring 2022</div>
* ECE 499/ECE 590: Machine Learning for Embedded Systems [[Home Page]](/2021/09/01/ML4Emb) <div style="float:right">Fall 2021</div>

** Univeristy of Notre Dame **
* IBM Qiskit Hands on Training Course, Winter Break 20-21, (Lecturer for QML) <div style="float:right">Dec. 2020 – Jan. 2021</div>
	- Documents: [[Syllabus]](./Qiskit-syllabus.pdf) [[QML-1]](./Course1_Framework.pdf) [[QML-2]](./Course2_QuantumFlow.pdf)
	- Records: [[QML]](https://drive.google.com/drive/folders/1oS_1AzxFRGzSw9Wozp-u7rcWRXz1gFAj?usp=sharing)
* Logic Design and Sequential Circuits, CSE20221 (TA for Dr. Jay Brockman) <div style="float:right">Jan. 2020 – May 2020</div>
	- Documents: [[TA-list]](./CSE20221_Spring2020TA.pdf) [[C-Tutorial]](./CSE20221_C_Tutorial.pdf)
* Machine Learning for Embedded Systems, CSE60685 (TA for Dr. Yiyu Shi) <div style="float:right"> Jan. 2020 – May 2020</div>
* Striving for Excellence in Teaching (certificate, work-in-progress)

** Univeristy of Pittsburgh **
* INVESTING NOW summer program (Volunteer)

** Chongqing Univeristy **
* High-Performance Parallel Computing (TA for Dr. Edwin Sha)<div style="float:right">Sep. 2014 – Jun. 2015</div>