---
date: 2022-01-01 16:00:00
title: Hardware Accelerators for Machine Learning (Spring 2022)
categories: teaching
type: course
---

### ECE 618

## Coure Inforamtion
| <b>Instructor</b>  | Dr. Weiwen Jiang |
|--------------|----------------------------|
| <b>E-Mail</b>|wjiang8@gmu.edu|  
| <b>Phone</b>|(703)993-5083|  
| <b>Lecture Time</b> |Monday 19:20 - 22:00 |
| <b>Location</b> |Room 1002, Music/Theater Building|
| <b>Office Hour</b> | Monday 16:30 - 17:30 |
| <b>Office</b> | Room 3247, Nguyen Engineering Building|
| <b>Zoom</b> | http://go.gmu.edu/zoom4weiwen |


## Course Materials
Course materials will be posted before or after the class. No formal textbook is required. 

## Recommended Prerequisites
ECE 554 (ECE 499/590 in Fall 2021: Machine Learning for Embedded Systems) with the minimum grade of B- or permission of instructor.


## Course Description

This course covers the hardware design principles to deploy different machine learning algorithms. The emphasis is on understanding the fundamentals of machine learning and hardware architectures and determine plausible methods to bridge them. Topics include precision scaling, in-memory computing, hyperdimensional computing, architectural modifications, GPUs and vector architectures, quantum computing as well as recent hardware programming tools such as Xilinx AI Vitis, Xilinx HLS, and IBM Qiskit.

## Tools for Lab

* Google [Colab](https://colab.research.google.com/)
* Xilinx [High-Level Synthesis](https://www.xilinx.com/support/download/index.html/content/xilinx/en/downloadNav/vivado-design-tools/2021-1.html)
* IBM [Qiskit](https://www.ibm.com/quantum-computing/)

## Schedule and Documents
[[Syllabi]](./syllabi/ECE618_2022_Syllabus.pdf)


| <b>W</b>  |  <b>Date</b> | <b>Topic</b> | <b>Documents</b> | <b>Note</b> |
|-----------------|--------------|--------------|------------------|-------------|
|				  |			  	 | **Session I: Classical Computing Accelerators for Machine Learning** |   |  |
| 1				  | Jan. 24		 | Course Information & Machine Learning and FPGA Accelerator Recap |   |  | 
| 2			      | Jan. 31  	 | Vector Architectures, FPGAs and GPU Architectures|||
| 3			      | Feb. 7  	 | ASIC Accelerators|||
|				  |			  	 | **Session II: Novel Post-Moore Computing Accelerators for ML** |   |  |
| 4			      | Feb. 14  	 | In-Memory Computing Accelerator Design|||
| 5			      | Feb. 21  	 | Neuromorphic Accelerators|||
| 6			      | Feb. 28  	 | Hyperdimensional Computing Accelerators|||
| 7			      | Mar. 07  	 | Quantum Neural Network Accelerators|||
| 8			      | Mar. 21  	 | Midterm Exam |||
|				  |			  	 | **Session III: Other Accelerator Related Topics** |   |  |
| 9			      | Mar. 28  	 | Project Proposal|||
| 10		      | Apr. 04  	 | Distributed Learning |||
| 11		      | Apr. 11  	 | Hands-on Accelerator Design (1)|||
| 12		      | Apr. 18  	 | Project Overview|||
| 13		      | Apr. 25  	 | Hands-on Accelerator Design (2)|||
| 14		      | May 02  	 | Project Presentations|||
| 15		      | May 11-18    | Final exam |||
