---
date: 2021-12-31 22:38:00
title: Yi Sheng
categories: blog
---

   

<img src="Yi/yi.jpg" align="left" width="180px" hight="100px" border="0" hspace="0" style="margin-right:20px;"/>


**I am currently a Ph.D. student in the Department of Electrical and Computer Engineering at George Mason University (GMU), 
**advised by [Prof. Weiwen Jiang](https://jqub.github.io/). I obtained my master degree from the Department of Telecommunication 
**Engineering at Universitat Politècnica de Catalunya (UPC) in 2021. 
**And I received my bachelor degree from the School of Telecommunication at Jilin University in 2016.**       

**My research interests lie in software and hardware co-design，FPGA-based accelerator design.**


* **B.Eng. in Optical Communication , Jilin University, China**
* **M.S. in Telecommunication Engineering, Universitat Politècnica de Catalunya, Spain**
* **Ph.D. in Electrical and Computer Engineering, George Mason University, USA**

# Publications 
----
**FL-DISCO: Federated Generative Adversarial Network for Graph-based Molecule Drug Discovery**  
D. Manu, **Y. Sheng**, Junhuan Yang, Jieren Deng, Tong Geng, Ang Li, Caiwen Ding, Weiwen Jiang, Lei Yang,
*IEEE/ACM International Conference On Computer-Aided Design (ICCAD), Virtual*, 2021. (Invited paper)     
   
**Federated Contrastive Learning for Dermatological Disease Diagnosis via On-device Learning**       
Y. Wu, D. Zeng, Z. Wang, **Y. Sheng**, L. Yang, A. James, Y. Shi, J. Hu,
*Accepted by IEEE/ACM International Conference On Computer-Aided Design (ICCAD), Virtual*, 2021. (Invited paper)    
      

    
# Honors & Awards
----
* **Visiting Bachelor Student**, *Sun Yat-sen University*, 2013-2014
* **Third-class Scholarship**, *Ministry of Education of China*, 2013,2014,2015
5


# Contact
-----
* **Email**: ysheng2 \[AT\] gmu \[DOT\] edu
* **Address**: 4104, Nguyen Engineering Building, 4511 Patriot Circle, Fairfax, Virginia, 22030
